import React, { Component } from 'react';
import Auji from './logo.png';
import buji from './name.png';
import { useNavigate } from 'react-router-dom';
import './List.css';
export const List=()=>  {
    const navigate=useNavigate();
        return (
            <div className='lost'>
                <p className='sglst'>1.Tasakku Tasakku</p>
            </div>
        );
    }
 